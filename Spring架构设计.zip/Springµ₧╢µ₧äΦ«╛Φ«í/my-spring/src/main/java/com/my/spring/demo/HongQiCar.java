package com.my.spring.demo;

/**
 * @author Zijian Liao
 * @since 1.0.0
 */
public class HongQiCar {

    public void run(){
        System.out.println("hongqi running");
    }
}