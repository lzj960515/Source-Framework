package com.my.spring.demo;

/**
 * @author Zijian Liao
 * @since 1.0.0
 */
public class GeelyCar {

    public void run(){
        System.out.println("geely running");
    }
}
