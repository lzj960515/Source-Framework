package com.my.spring.gooddemo;

/**
 * @author Zijian Liao
 * @since 1.0.0
 */
public class GeelyCar implements Car {

    @Override
    public void run(){
        System.out.println("geely running");
    }
}
